# VEV QUIZER - Quiz Staking App

A mobile quiz application where users can stake money, answer questions, and win real cash prizes.

## Features

### 🎮 Game Modes
- **Quick Play**: 10 questions, 60 seconds, 3x multiplier
- **Level Quiz**: Choose difficulty (Good, Smart, Best) with different stakes
- **Quiz Battle**: Compete with 3+ players
- **1 vs 1**: Head-to-head battles with online players

### 💰 Wallet System
- Deposit funds (min ₦50)
- Withdraw winnings (min ₦500, max ₦5,000,000)
- View transaction history
- Platform fee: 10% on winnings

### 🎁 Rewards
- ₦30 welcome bonus
- Daily free spins on Lucky Wheel
- Badge system with multipliers:
  - Bronze (1.1x)
  - Silver (1.2x)
  - Gold (1.3x)
  - Platinum (1.4x)
  - Grand Master (1.5x)
  - God (2.0x)
  - Genius (3.0x)

### 🔐 Security
- JWT authentication
- Device ID tracking (max 3 accounts per device)
- OTP password recovery
- Rate limiting on login attempts
- Account lockout after 5 failed attempts

### 📱 Features
- Real-time leaderboard
- Profile management
- In-app notifications
- Sound effects
- Dark/Light mode

## Tech Stack

- React Native / Expo
- React Navigation
- Axios for API calls
- AsyncStorage for local storage
- Expo AV for sounds
- Expo Device for device identification

## Setup Instructions

### Prerequisites
- Node.js 16+
- npm or yarn
- Expo CLI (`npm install -g expo-cli`)
- Expo Go app on your phone

### Installation

1. Clone the repository:
```bash
git clone https://github.com/vetoudofia/vev-quizer.git
cd vev-quizer